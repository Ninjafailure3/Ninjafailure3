- 👋 Hi, I’m @Ninjafailure3
- 👀 I’m interested in games
- 🌱 I’m currently learning how to make one myself
- 💞️ I’m looking to collaborate on my first one with my friend
- 📫 How to reach me: discord- ninjafailure3#3708 ; instagram- ninjafailure3 ; twitter- Windoge93

<!---
Ninjafailure3/Ninjafailure3 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
